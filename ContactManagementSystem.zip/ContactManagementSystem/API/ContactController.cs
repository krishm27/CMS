﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using ContactManagementSystem.Models;
using System.Web.Http.Description;
using System.Data.Entity;

namespace ContactManagementSystem.API
{
    [RoutePrefix("api/Contact")]
    public class ContactController : ApiController
    {
        // ContactManagementEntities object
        ContactManagementEntities dbContext = null;
        
        // Constructor
        public ContactController()
        {
            // create instance of the object
            dbContext = new ContactManagementEntities();
        }

        [ResponseType(typeof(Contact))]
        [HttpPost]
        public HttpResponseMessage SaveContact(Contact newContact)
        {  
            int result = 0;
            try {
                dbContext.Contacts.Add(newContact);
                dbContext.SaveChanges();
                result = 1;
            }
            catch (Exception ex) {  
                result = 0;
            }  
            return Request.CreateResponse(HttpStatusCode.OK, result);
        }

        [ResponseType(typeof(Contact))]
        [HttpGet]
        public List<Contact> GetContacts()
        {
            List<Contact> contacts = null;
            try
            {
                contacts = dbContext.Contacts.ToList();
            }
            catch (Exception ex)
            {
                contacts = null;
            }
            return contacts;
        }

        [Route("GetContactById/{contactId:int}")]
        [ResponseType(typeof(Contact))]
        [HttpGet]
        public Contact GetContactById(int contactId)
        {
            Contact contact = null;
            try
            {
                contact = dbContext.Contacts.Where(x => x.ContactId == contactId).SingleOrDefault();
            }
            catch (Exception e)
            {
                contact = null;
            }
            return contact;
        }

        [ResponseType(typeof(Contact))]
        [HttpPut]
        public HttpResponseMessage UpdateContact(Contact aContact)
        {
            int result = 0;
            try
            {
                dbContext.Contacts.Attach(aContact);
                dbContext.Entry(aContact).State = EntityState.Modified;
                dbContext.SaveChanges();
                result = 1;
            }
            catch (Exception ex)
            {
                result = 0;
            }
            return Request.CreateResponse(HttpStatusCode.OK, result);
        }

        [Route("DeleteContact/{id:int}")]
        [ResponseType(typeof(Contact))]
        [HttpDelete]
        public HttpResponseMessage DeleteContact(int id)
        {
            int result = 0;
            try
            {
                var contact = dbContext.Contacts.Where(x => x.ContactId == id).FirstOrDefault();
                dbContext.Contacts.Attach(contact);
                dbContext.Contacts.Remove(contact);
                dbContext.SaveChanges();
                result = 1;
            }
            catch (Exception ex)
            {
                result = 0;
            }
            return Request.CreateResponse(HttpStatusCode.OK, result);
        }
    }
}
