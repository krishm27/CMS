﻿app.controller('ContactCtrl', ['$scope', 'CMService',
    function ($scope, CMService) {
        // Base Url
        var baseUrl = '/api/Contact/';
        $scope.btnText = "Add Contact";
        $scope.contactId = 0;
        $scope.loading = false;
        $scope.contacts = [];

        $scope.predicate = 'ContactId';
        $scope.reverse = true;
        $scope.currentPage = 0;
        $scope.totalItems = $scope.contacts.length;
        $scope.numPerPage = 5;
        $scope.OrderData = function (predicate) {
            $scope.reverse = ($scope.predicate === predicate) ? !$scope.reverse : false;
            $scope.predicate = predicate;
        }

        $scope.Paginate = function (index) {
            $scope.currentPage = index;
        }

        $scope.ClearSort = function () {
            $scope.predicate = 'ContactId';
            $scope.reverse = false;
            $scope.OrderData($scope.predicate);
        }

        $scope.SetPageSize = function (pageSize) {
            $scope.currentPage = 0;
            $scope.numPerPage = pageSize;
            $scope.numOfPagesArr = new Array(Math.ceil($scope.contacts.length / $scope.numPerPage));
            for (var i = 0; i < $scope.numOfPagesArr.length; i++) {
                $scope.numOfPagesArr[i] = i;
            }
        }

        $scope.SaveUpdate = function () {
            // Validate form
            if (!$scope.frmContact.$valid) {
                return false;
            }

            var contact = {
                FirstName: $scope.firstName,
                LastName: $scope.lasttName,
                Email: $scope.email,
                Phone: $scope.phone,
                Status: $scope.status,
                ContactId: $scope.contactId
            }
            if ($scope.btnText == "Add Contact") {
                var apiRoute = baseUrl + 'SaveContact/';
                var saveContact = CMService.post(apiRoute, contact);
                saveContact.then(function (response) {
                    if (response.data != "") {
                        $scope.GetContacts();
                        $scope.Clear();
                    } else {
                        alert("Error");
                    }
                }, function (error) {
                    console.log("Error: " + error);
                });
            }
            else {
                var apiRoute = baseUrl + 'UpdateContact/';
                var updateContact = CMService.put(apiRoute, contact);
                updateContact.then(function (response) {
                    if (response.data != "") {
                        $scope.GetContacts();
                        $scope.Clear();
                    } else {
                        alert("Error");
                    }
                }, function (error) {
                    console.log("Error: " + error);
                });
            }
        }

        $scope.Clear = function () {
            $scope.contactId = 0;
            $scope.firstName = "";
            $scope.lasttName = "";
            $scope.email = "";
            $scope.phone = "";
            $scope.status = "";
            $scope.btnText = "Add Contact";
        }

        $scope.GetContacts = function () {
            $scope.loading = true;
            $scope.contacts.length = 0;
            var apiRoute = baseUrl + 'GetContacts/';
            var contactsList = CMService.getAll(apiRoute);
            contactsList.then(function (response) {
                $scope.contacts = response.data;
                $scope.numOfPagesArr = new Array(Math.ceil($scope.contacts.length / $scope.numPerPage));
                for (var i = 0; i < $scope.numOfPagesArr.length; i++) {
                    $scope.numOfPagesArr[i] = i;
                }
                $scope.loading = false;
            }, function (error) {
                $scope.loading = false;
                console.log("Error: " + error);
            });
        }
        $scope.GetContacts();

        $scope.GetContactById = function (aContact) {
            var apiRoute = baseUrl + 'GetContactById';
            var contact = CMService.getbyID(apiRoute, aContact.ContactId);
            contact.then(function (response) {
                $scope.contactId = response.data.ContactId;
                $scope.firstName = response.data.FirstName;
                $scope.lasttName = response.data.LastName;
                $scope.email = response.data.Email;
                $scope.phone = response.data.Phone;
                $scope.status = response.data.Status;
                $scope.btnText = "Update";
            }, function (error) {
                console.log("Error: " + error);
            });
        }

        $scope.DeleteContact = function (aContact) {
            var apiRoute = baseUrl + 'DeleteContact/' + aContact.ContactId;
            var deleteContact = CMService.delete(apiRoute);
            deleteContact.then(function (response) {
                if (response.data != "") {
                    $scope.GetContacts();
                    $scope.Clear();
                } else {
                    alert("Error");
                }
            }, function (error) {
                console.log("Error: " + error);
            });
        }
    }
]);